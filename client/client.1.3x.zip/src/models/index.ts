 import common from './common';

import classification from '../pages/classification/model';


export default [
   common,
classification,
]