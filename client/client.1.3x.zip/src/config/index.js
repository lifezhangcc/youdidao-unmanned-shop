// 请求连接前缀
export const apiOrigin = 'https://api.hetuntech.cn/';

// 输出日志信息
export const noConsole = false;

// 图片源
export const imageOrigin = 'https://images.xxx.com/';
